#Examplefuncsplayer2

Modified version of Examplefuncsplayer
- Soldiers move towards visible enemies
- Miners move to and stay on resources.
- All still move randomly if nothing is seen.
- No Deposit control (deposits are still mined out completely)
- Builds Sages if collected enough gold from dead enemies
    - Sages act the same as soldiers