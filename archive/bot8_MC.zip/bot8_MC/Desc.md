# Bot8_MC

copied from bot5_JJ8

soldiers
when retreating they stay within action radius of archon
retreats when health<17
stays until health>=49
doesn't broadcast ID to array

- 31: Soldier Healing
- 32: Solider Healing
- 33: Soldier Healing
- 34: Soldier Healing
  When miners find a de 41: minorLocation (Where enemy is)  (Not Used Currently)
- 42: enemy seen
- 43: Archon Locations
- 44: global miner count
- 45: return to archon
- 46: soldier flag
- 47: soldier move central
  48 - used to tell friendly soldiers possible enemy archon locations
  49 - locations of archon 0-1
  50 - locations of archon 2-3