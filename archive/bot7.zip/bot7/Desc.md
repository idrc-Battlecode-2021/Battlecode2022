# Bot7
Uses bot5_SL

- archon prioritizes spawning troops on low rubble
- archon doesn't stop spawning if another archon is building 
^above changes improve bot
- improve 