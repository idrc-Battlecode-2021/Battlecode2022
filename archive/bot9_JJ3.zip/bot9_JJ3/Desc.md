# Bot9 JJ

- Different archon healing method
- Different soldier retreat method
- Archon tries moves to low passability every turn after minerCount>6 (might want to change for only after vortex anomaly)
- robots get reassigned to a random archon after its archon has died
- Soldiers now stores targets instead of immediately overriding them.
- Soldiers Try to follow Miners


- 31: Soldier Healing
- 32: Solider Healing
- 33: Soldier Healing
- 34: Soldier Healing
  When miners find a de 41: minorLocation (Where enemy is)  (Not Used Currently)
- 42: enemy seen
- 43: Archon Locations
- 44: global miner count
- 45: return to archon
- 46: soldier flag
- 47: soldier move central
  48 - used to tell friendly soldiers possible enemy archon locations
  15 - location of archon 0
  16 - location of archon 1
  49 - locations of archon 2
  50 - locations of archon 3