# Bot5_SL
Basically Bot5_MC but with better soldiers