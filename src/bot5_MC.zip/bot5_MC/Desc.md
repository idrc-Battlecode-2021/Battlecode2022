# ocasiybfrtiygn oataktc tt r eoee

slcPitttrroiygoapssibla e mvsowolt retn igarttTeeeagre s
When miners find a de 41: minorLocation (Where enemy is)  (Not Used Currently)
- 42: enemy seen
- 43: Archon Locations
- 44: global miner count
48 - used to tell friendly soldiers possible enemy archon locations
49 - locations of archon 0-1
50 - locations of archon 2-3