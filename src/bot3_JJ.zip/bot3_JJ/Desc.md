# Third Bot Variant
- When 1 miner finds a deposit, another is built


# IDs
- Archon ID's are all +1

#Shared Array

When miners find a deposit
- 31: minerFound 1
- 32: minerFound 2
- 33: minerFound 3
- 34: minerFound 4
- 36: minerAlert (WIP)
- 37: minerAlert (WIP)
- 38: minerAlert (WIP)
- 39: minerAlert (WIP)
- All Other ids the same

#Bugs
- Miners get stuck in corners
- Sometimes Miners don't go to lead deposits
- Too Many WatchTowers
- Too Many Miners