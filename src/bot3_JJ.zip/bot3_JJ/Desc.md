# Third Bot Variant
- When 1 miner finds a deposit, another is built
- Unsless

# IDs
- Archon ID's are all +1

#Shared Array

When miners find a deposit
- 31: minerFound 1
- 32: minerFound 2
- 33: minerFound 3
- 34: minerFound 4
- All other ids the same