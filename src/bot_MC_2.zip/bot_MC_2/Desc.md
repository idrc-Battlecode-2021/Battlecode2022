# Bot MC 2
Attempt at a more aggressive strategy

Archon:
spawns miners until an ally troop has detected enemy
once the archon detected an enemy, continually spawn soldiers

## Shared Array
12 - location of first enemy troop