# Bot9_MC2

- Bot9_MC but with kiting and other soldier micro



- 31: Soldier Healing
- 32: Solider Healing
- 33: Soldier Healing
- 34: Soldier Healing
  When miners find a de 41: minorLocation (Where enemy is)  (Not Used Currently)
- 42: enemy seen
- 43: Archon Locations
- 44: global miner count
- 45: return to archon
- 46: soldier flag
- 47: soldier move central
  48 - used to tell friendly soldiers possible enemy archon locations
  15 - location of archon 0
  16 - location of archon 1
  49 - locations of archon 2
  50 - locations of archon 3