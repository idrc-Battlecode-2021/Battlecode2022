# Third Botame
- minhe beginning, getal 06ers capped at t ni 0334

## Buildings### Archons
#### Spawning
- miners spawn in lategame
- 1 lab globally instead of 1 lab each
- defensive watchtowers built before labs
- minimum miners to maintain may change based on # of lead deposits around archon

#### Changelog


### Labs
### Watchtowers
## Droids
### TODO
- Create a Better Exploration Method
- Create a Better Pathfinding algorithm
### Builders
- work on lattice stuff
#### Changelog
- 1/6/2022 - work on watchtower lattice.
### Miners
#### TODO
- Optimize resource locator
- Further Optimize Bytecode Usage
### Sages
### Soldiers
